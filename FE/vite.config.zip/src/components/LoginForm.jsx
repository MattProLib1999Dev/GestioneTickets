import "bootstrap/dist/css/bootstrap.min.css";
import RegisterForm from "./RegisterForm";
import {UploadImage} from "./ControlloLogin";

const LoginForm = () => (
  <>
    <UploadImage />
    <RegisterForm />
  </>
);


export default LoginForm;
