export default function BottoneLogout(props) {
    return <button onClick={props.onClick}>Logout</button>;
  }