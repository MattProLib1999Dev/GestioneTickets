import React, { useState, useEffect } from 'react';
import { getImage } from '../api/Image';
import LoginForm from './LoginForm'; // importa o definisci il componente

export function UploadImage() {
  const [images, setImages] = useState([]);

  useEffect(() => {
    const fetchImage = async () => {
      try {
        const response = await getImage();
        setImages(response.data);
      } catch (error) {
        console.error("Errore nel recupero dell'immagine:", error);
      }
    };

    fetchImage();
  }, []);

  const handleSubmit = (event) => {
    event.preventDefault();
    // logica di submit (es. upload)
    console.log('Submit chiamato');
  };

  return (
    <div>
      <div>
        {images.map((img) => (
          <div key={img.fileName}>
            <p>{img.fileName}</p>
            <p>{img.contentType}</p>
          </div>
        ))}
      </div>

      <div>
        <LoginForm onSubmit={handleSubmit} />
      </div>
    </div>
  );
}
