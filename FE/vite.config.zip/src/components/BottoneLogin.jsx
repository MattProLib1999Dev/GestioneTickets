export default function BottoneLogin(props) {
    return <button onClick={props.onClick}>Login</button>;
  }
  